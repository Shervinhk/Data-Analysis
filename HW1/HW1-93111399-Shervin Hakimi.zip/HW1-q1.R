# first we will install the magic package:
install.packages("magic")
# Now we will use this package:
library("magic")
#---------------------------------
# 4dimensional:
magichypercube.4n(1,d=4)

# 5dimensional:
magichypercube.4n(1,d=5)

# 6dimensional:
magichypercube.4n(1,d=6)
#---------------------------------